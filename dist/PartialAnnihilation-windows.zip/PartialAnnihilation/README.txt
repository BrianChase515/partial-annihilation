Partial Annihilation v0.28.27

Double-click PartialAnnihilation.exe to play.
Windows may warn that the app is from an unknown publisher: click "More info", then "Run anyway".
